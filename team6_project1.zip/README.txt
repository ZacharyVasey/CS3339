Run the following command to run the python program

python team6_project1.py -i test2_bin.txt -o team6.out

OR to run another test case

python team6_project1.py -i <--machine code file txt--> -o team6.out

Group members
Anne Leach - al140
Zachary Vasey - zwv2